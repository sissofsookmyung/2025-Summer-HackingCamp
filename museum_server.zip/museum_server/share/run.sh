#!/bin/sh

cd /home/pwn
exec timeout 30 ./chall
